/*********************************************************************************
*  WEB700 – Assignment 04
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  No part 
*  of this assignment has been copied manually or electronically from any other source 
*  (including 3rd party web sites) or distributed to other students.
* 
*  Name: nirajbhai limbasiya Student ID: 146215231  Date: 18/07/2024
*
********************************************************************************/ 
const express = require('express');
const path = require('path');
const collegeData = require('./collegeData');
// Middleware
app.use(express.urlencoded({ extended: true }));
app.get('/students/add', (req, res) => {
    res.sendFile(path.join(__dirname, '/views/addStudent.html'));
});
app.post('/students/add', (req, res) => {
    collegeData.addStudent(req.body).then(() => {
        res.redirect('/students');
    }).catch(err => {
        res.status(500).send('Unable to add student');
    });
});
// Static files
app.use(express.static('public'));

app.use(express.static(path.join(__dirname, 'public')));

// Define middleware

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
var HTTP_PORT = process.env.PORT || 8080;
var app = express();
const port = 8080;
app.get("/", (req, res) => {
    res.send("Hello World!");
});

app.get('/about', (req, res) => {
    res.send('Welcome to the About Page');
});

app.get('/htmlDemo', (req, res) => {
    res.send('Welcome to the HTML Demo Page');
});

app.get('/students', async (req, res) => {
    try {
        const students = await collegeData.getAllStudents();
        res.json(students);
    } catch (error) {
        res.status(500).send(error.message);
    }
});

app.get('/students/:studentNum', async (req, res) => {
    try {
        const student = await collegeData.getStudentByNum(req.params.studentNum);
        res.json(student);
    } catch (error) {
        res.status(500).send(error.message);
    }
});

app.get('/studentsByCourse/:course', async (req, res) => {
    try {
        const students = await collegeData.getStudentsByCourse(req.params.course);
        res.json(students);
    } catch (error) {
        res.status(500).send(error.message);
    }
});
// setup http server to listen on HTTP_PORT
app.listen(HTTP_PORT, () => {
    console.log("Server listening on port: " + HTTP_PORT);
});
